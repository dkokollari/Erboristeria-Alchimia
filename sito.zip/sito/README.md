# Erboristeria-Alchimia
Progetto Tecnologie Web 2019/2020

## Membri del gruppo:

* Andrea Dorigo
* Dardan Kokollari
* Fouad Mouad
* Marcel Wandji

##Validazione

 -https://validator.w3.org/;
 -lang=eng, lang=it dove necessario;
 -controllo simboli (tipo e' accentata)
 -controllo navigazione da tastiera;
 -controllo fallback browser: se browser non ha x funzione html deve fare y (se non hai grid mostra questa);
 -controllo contrasti
 -aiuti alla navigazione(tasto torna su ecc)
 -aiuti alla nvaigazione(salta qui)
 -scaricarsi https://www.totalvalidator.com/downloads/basic.html e validiamo con questo;
 -scaricarsi https://silktide.com/features/accessibility: estensione chrome accssibilità.
